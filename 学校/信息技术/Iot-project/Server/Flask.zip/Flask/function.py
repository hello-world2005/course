def FetchData():
  return None